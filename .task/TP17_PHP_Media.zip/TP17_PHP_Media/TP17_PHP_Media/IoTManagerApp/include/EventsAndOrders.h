#pragma once
#include "Global.h"

extern void generateOrder(const String& id, const String& value);
extern void handleOrder();

extern void generateEvent(const String& id, const String& value);
extern void handleEvent();