#pragma once
#include "Global.h"
#include "MqttClient.h"

void eventGen2(String eventName, String eventValue);
extern void spaceCmdExecute(String &cmdStr);
extern String getValueJson(String &key);