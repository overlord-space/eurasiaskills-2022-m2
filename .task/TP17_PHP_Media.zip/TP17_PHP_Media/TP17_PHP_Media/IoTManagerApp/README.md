# IoTManager
Это модульная система беспроводной автоматизации на базе ESP32/ESP8266 микроконтроллеров и приложения IoT Manager.   
Телеграм канал обсуждения приложения и системы автоматизации  https://t.me/IoTmanager
# [Инструкция](https://github.com/IoTManagerProject/IoTManager/wiki)

![](https://github.com/IoTManagerProject/IoTManager/blob/beta/doc/pictures/007%20iot%20manager.jpg)
